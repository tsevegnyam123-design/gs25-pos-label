Replace your repository index.html with the included index.html file.
